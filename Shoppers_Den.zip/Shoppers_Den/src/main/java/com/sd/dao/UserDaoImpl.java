package com.sd.dao;

import com.sd.helpers.PostgresConnHelper;
import com.sd.models.Cart;
import com.sd.models.User;
import com.sd.models.UserRole;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class UserDaoImpl implements UserDao{
    private Connection conn;
    private PreparedStatement pu,pc,du,uun,pci;
    private Statement statement;
    private ResultSet resultSet,resultSet2;
    private ResourceBundle resourceBundle;

    public UserDaoImpl()
    {
        conn= PostgresConnHelper.getConnection();
        if(conn!=null)
        {
            System.out.println("Connection Established...");
        }
        else
        {
            System.out.println("Connection has issue...");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }




    @Override
    public void addUser(User user) throws SQLException {
        String adduser=resourceBundle.getString("addUser");
        String addcart=resourceBundle.getString("addcart");
        try
        {
            pu=conn.prepareStatement(adduser);
            pu.setLong(1,user.getPhoneNumber());
            pu.setString(2,user.getUserName());
            pu.setString(3,user.getEmail());
            pu.setString(4,user.getPassword());
            pu.setString(5,user.getAddress());
            pu.setString(6,user.getAnswer());
            if(user.getUserRole().equals(UserRole.ADMIN))
            {
                pu.setInt(7,1);

            }
            else
            {
                pu.setInt(7,2);
            }
            pu.setInt(8,user.getUserid());
            pu.setString(9,user.getSecurityQuestion());
            pu.setInt(10,user.getEnabled());
            pu.executeUpdate();

            pc = conn.prepareStatement(addcart);
            pc.setInt(1,user.getCart().getCartId());
            pc.setInt(2,user.getUserid());
            pc.executeUpdate();
        }
        catch (SQLException e)
        {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public List<User> getAllUsers() throws SQLException {
        List<User>userList=new ArrayList<User>();
        User user = null;
        String query = resourceBundle.getString("selectUser");
        statement = conn.createStatement();
        resultSet=statement.executeQuery(query);
        while(resultSet.next())
        {
            user = new User();
            user.setPhoneNumber(resultSet.getInt(1));
            user.setUserName(resultSet.getString(2));
            user.setEmail(resultSet.getString(3));
            user.setPassword(resultSet.getString(4));
            user.setAddress(resultSet.getString(5));
            user.setAnswer(resultSet.getString(6));
            if(resultSet.getInt(7)==1)
            {
                user.setUserRole(UserRole.ADMIN);
            }
            else
            {
                user.setUserRole(UserRole.CUSTOMER);
            }
            user.setUserid(resultSet.getInt(8));
            user.setSecurityQuestion(resultSet.getString(9));
            user.setEnabled(resultSet.getInt(10));
            String query2 = resourceBundle.getString("getcbyuid");
            pci=conn.prepareStatement(query2);
            pci.setInt(1,resultSet.getInt(8));
            resultSet2=pci.executeQuery();
            Cart cart = new Cart();
            while (resultSet2.next())
            {
                cart.setCartId(resultSet2.getInt(1));
                cart.setUser(user);
            }
            user.setCart(cart);
            userList.add(user);
        }
        return userList;
    }

    @Override
    public void updateUserName(int userId, String name) throws SQLException {
        String query = resourceBundle.getString("updateusername");
        uun = conn.prepareStatement(query);
        uun.setString(1,name);
        uun.setInt(2,userId);
        uun.executeUpdate();
    }

    @Override
    public void deleteUser(int userId) throws SQLException {
        String query = resourceBundle.getString("deleteuser");
        du = conn.prepareStatement(query);
        du.setInt(1,userId);
        du.executeUpdate();
    }

    @Override
    public User getUser(int userid) throws SQLException {
        User user = new User();
        String query = resourceBundle.getString("selectUser1");
        statement = conn.createStatement();
        resultSet=statement.executeQuery(query+userid);
        while(resultSet.next()) {
            user.setPhoneNumber(resultSet.getInt(1));
            user.setUserName(resultSet.getString(2));
            user.setEmail(resultSet.getString(3));
            user.setPassword(resultSet.getString(4));
            user.setAddress(resultSet.getString(5));
            user.setAnswer(resultSet.getString(6));
            if (resultSet.getInt(7) == 1) {
                user.setUserRole(UserRole.ADMIN);
            } else {
                user.setUserRole(UserRole.CUSTOMER);
            }
            user.setUserid(resultSet.getInt(8));
            user.setSecurityQuestion(resultSet.getString(9));
            user.setEnabled(resultSet.getInt(10));

            String query2 = resourceBundle.getString("getcbyuid");
            pci=conn.prepareStatement(query2);
            pci.setInt(1,resultSet.getInt(8));
            resultSet2=pci.executeQuery();
            Cart cart = new Cart();
            while (resultSet2.next())
            {
                cart.setCartId(resultSet2.getInt(1));
                cart.setUser(user);
            }
            user.setCart(cart);
        }
        return user;
    }
}
