package com.sd.dao;

import com.sd.models.Order;
import com.sd.models.Product;
import com.sd.models.User;

import java.sql.SQLException;
import java.util.List;

public interface OrderDao {
    void placeOrder(User user, Order order) throws SQLException;
    void cancelOrder(int order_id) throws SQLException;
//    void updateOrder(User user);
    List<Order> viewAllOrder(User user) throws SQLException;
    Order getOrderById(User user,int orderId) throws SQLException;
    void confirmOrder(User user, int order_id) throws SQLException;
    public List<Product> showOrderItems(int order_id) throws SQLException;
}
