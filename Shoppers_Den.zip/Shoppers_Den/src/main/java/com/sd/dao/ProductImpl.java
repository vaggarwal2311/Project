package com.sd.dao;

import com.sd.models.Category;
import com.sd.models.Product;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import com.sd.helpers.PostgresConnHelper;
import com.sd.models.User;


import java.sql.*;

import java.util.ResourceBundle;

public class ProductImpl implements ProductDao{

    private Connection conn;
    private PreparedStatement ap,dp,up,pbi;
    private Statement statement;
    private ResultSet resultSet;
    private ResourceBundle resourceBundle;

    public ProductImpl()
    {
        conn= PostgresConnHelper.getConnection();
        if(conn!=null)
        {
            System.out.println("Connection Established...");
        }
        else
        {
            System.out.println("Connection has issue...");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }


    @Override
    public void addProduct(Product product) {
        String addProduct=resourceBundle.getString("addP");
        try
        {
            ap=conn.prepareStatement(addProduct);
            ap.setDate(1, Date.valueOf(LocalDate.now()));
            ap.setString(2,product.getPdesc());
            ap.setInt(3,product.getPid());
            ap.setString(4,product.getPname());
            ap.setLong(5,product.getPrice());
            ap.setInt(6,product.getQty());
            ap.setInt(7,product.getCategory().getCid());
            ap.executeUpdate();
        }
        catch (SQLException e)
        {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void updateProductName(int p_id, String p_name) throws SQLException {
        String query = resourceBundle.getString("updateP");
        up = conn.prepareStatement(query);
        up.setString(1,p_name);
        up.setInt(2,p_id);
        up.executeUpdate();
    }

    @Override
    public void deleteProduct(int p_id) throws SQLException {
        String query = resourceBundle.getString("deleteP");
        dp = conn.prepareStatement(query);
        dp.setInt(1,p_id);
        dp.executeUpdate();
    }

    @Override
    public List<Product> getAllProducts() throws SQLException {
        List<Product>productList=new ArrayList<Product>();
        Product product= null;
        String query = resourceBundle.getString("selectP");
        statement = conn.createStatement();
        resultSet=statement.executeQuery(query);
        while(resultSet.next())
        {
            product = new Product();
            product.setDate(resultSet.getDate(1).toLocalDate());
            product.setPdesc(resultSet.getString(2));
            product.setPid(resultSet.getInt(3));
            product.setPname(resultSet.getString(4));
            product.setPrice(resultSet.getLong(5));
            CategoryDao categoryDao = new CategoryImpl();
            Category category=categoryDao.getCategoryById(resultSet.getInt(7));
            product.setCategory(category);
            product.setQty(resultSet.getInt(6));
            productList.add(product);
        }
        return productList;
    }

    @Override
    public Product getProductById(int p_id) throws SQLException {
        Product product=new Product();
        String query = resourceBundle.getString("selectPById");
        pbi=conn.prepareStatement(query);
        pbi.setInt(1,p_id);
        resultSet=pbi.executeQuery();
        while(resultSet.next())
        {
            product.setDate(resultSet.getDate(1).toLocalDate());
            product.setPdesc(resultSet.getString(2));
            product.setPid(resultSet.getInt(3));
            product.setPname(resultSet.getString(4));
            product.setPrice(resultSet.getLong(5));
            CategoryDao categoryDao = new CategoryImpl();
            Category category=categoryDao.getCategoryById(resultSet.getInt(7));
            product.setCategory(category);
            product.setQty(resultSet.getInt(6));
        }
        return product;
    }
}
