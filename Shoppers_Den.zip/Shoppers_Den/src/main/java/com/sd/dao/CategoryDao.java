package com.sd.dao;
import com.sd.models.Category;
import java.sql.SQLException;
import java.util.List;
public interface CategoryDao {
    void addCategory(Category category);
    List<Category> getAllCategories() throws SQLException;
    Category getCategoryById(int categoryId) throws SQLException;
    void deleteCategory(int categoryId) throws SQLException;
    void updateCategory(int cid,String name) throws SQLException;
}