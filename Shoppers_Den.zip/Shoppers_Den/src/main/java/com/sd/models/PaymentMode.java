package com.sd.models;

public enum PaymentMode {
    Debit,Credit,UPI
}
