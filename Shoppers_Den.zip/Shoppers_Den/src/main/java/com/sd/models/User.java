package com.sd.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class User{
    private int userid;

    private long phoneNumber;

    private String userName;

    private String email;

    private String securityQuestion;

    private String password;

    private String address;

    private String answer;

    private int enabled;

    private UserRole userRole;

    private Cart cart;
}
