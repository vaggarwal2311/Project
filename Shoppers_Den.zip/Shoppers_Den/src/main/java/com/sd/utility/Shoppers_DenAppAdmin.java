package com.sd.utility;

import com.sd.dao.*;
import com.sd.models.*;


import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Scanner;

public class Shoppers_DenAppAdmin {
    private static final Scanner sc = new Scanner(System.in);
    public static void main(String[] args) throws SQLException {

        //User
        User user=null;

        //Order
        Order order=null;

        //Product
        Product product=null;

        //Category
        Category category=null;

        //CartItems
        CartItems cartItems=null;

        //Category Impl
        CategoryDao categoryDao = new CategoryImpl();

        //UserDao
        UserDao userDao = new UserDaoImpl();
        //CartItems
        CartDao cartDao=new CartDaoImpl();
        //Order
        OrderDao orderDao=new OrderDaoImpl();
        //Products
        ProductDao productDao=new ProductImpl();
        //login
        LoginDao login=new LoginImpl();

        System.out.println();
        loop:while(true) {
            System.out.println("Welcome to Shoppers_Den");
            System.out.println("1 - Login");
            System.out.println("2 - Register");
            System.out.println("3 - Exit");
            String way = sc.nextLine();
            switch (way.toLowerCase()) {
                case "login":
                    System.out.println("Enter your userId");
                    int id = Integer.parseInt(sc.nextLine());
                    System.out.println("Enter your password");
                    String pass = sc.nextLine();
                    if (login.check(id, pass)) {
                        user = userDao.getUser(id);
                    } else {
                        System.out.println("Enter a valid id or pass");
                    }
                    break loop;
                case "register":
                    user = createUser();
                    userDao.addUser(user);
                    System.out.println("You have been successfully registered with Login Id : " + user.getUserid());
                    continue loop;
                case "exit":
                    System.exit(0);
            }
        }

        System.out.println("You have been logged in with user id : " + user.getUserid());
        System.out.println("Welcome " + user.getUserName());
        ADMIN:while(true) {
            System.out.println("1 - Get all users ");
            System.out.println("2 - Delete User ");
            System.out.println("3 - Get a particular user ");
            System.out.println("4 - Add Product ");
            System.out.println("5 - Update Product Name ");
            System.out.println("6 - Delete Product ");
            System.out.println("7 - Get all Products ");
            System.out.println("8 - Get a particular product ");
            System.out.println("9 - Order History");
            System.out.println("10 - All Orders of User ");
            System.out.println("11 - Add Category ");
            System.out.println("12 - Delete Category ");
            System.out.println("13 - Update Category Name");
            System.out.println("14 - Get Category By ID ");
            System.out.println("15 - Get All Categories ");
            System.out.println("16 - View Profile ");
            System.out.println("17 - Update Profile ");
            System.out.println("18 - View Ordered Items ");
            System.out.println("19 - Log out and exit ");
            System.out.println("Enter your choice ");
            int c = Integer.parseInt(sc.nextLine());
            switch (c) {
                case 1:
                    for (User user1:userDao.getAllUsers())
                        System.out.println(user1.getUserid()
                                +" "+user1.getUserName()
                                +" "+user1.getEmail()
                                +" "+user1.getCart().getCartId()
                                +" "+user1.getPhoneNumber());
                    continue ADMIN;
                case 2:
                    System.out.println("Enter the user id to be deleted ");
                    int id = Integer.parseInt(sc.nextLine());
                    userDao.deleteUser(id);
                    System.out.println("The user had been successfully deleted ");
                    continue ADMIN;
                case 3:
                    System.out.println("Enter the id of user ");
                    int id1 = Integer.parseInt(sc.nextLine());
                    User user1 = userDao.getUser(id1);
                    System.out.println(user1.getUserName()
                            +" "+user1.getEmail()
                            +" "+user1.getPhoneNumber());
                    continue ADMIN;
                case 4:product=createProduct();
                       productDao.addProduct(product);
                       System.out.println("The product has been successfully added ");
                    continue ADMIN;
                case 5:
                    System.out.println("Enter the product id ");
                    int pid=Integer.parseInt(sc.nextLine());
                    System.out.println("Enter the updated name ");
                    String uname = sc.nextLine();
                    productDao.updateProductName(pid,uname);
                    System.out.println("The product name has been updated ");
                    continue ADMIN;
                case 6:
                    System.out.println("Enter the product id");
                    int pid1=Integer.parseInt(sc.nextLine());
                    productDao.deleteProduct(pid1);
                    System.out.println("The Product has been successfully deleted ");
                    continue ADMIN;
                case 7:for(Product product1:productDao.getAllProducts())
                    System.out.println(product1.getPid()+" "+product1.getPname()
                    +" "+product1.getCategory().getCname()
                    +" "+product1.getPrice()
                    +" "+product1.getQty() +" "+product1.getDate());
                    continue ADMIN;
                case 8:
                    System.out.println("Enter the product id ");
                    int pid2=Integer.parseInt(sc.nextLine());
                    Product product2=productDao.getProductById(pid2);
                    System.out.println(product2.getPid()+" "+
                            product2.getPname()+" "+
                            product2.getPrice()+" "+
                            product2.getQty());
                    continue ADMIN;
                case 9:
                    System.out.println("Enter the user id ");
                    int uid1=Integer.parseInt(sc.nextLine());
                    User user2=userDao.getUser(uid1);
                    System.out.println("Enter your oder id ");
                    int od=Integer.parseInt(sc.nextLine());
                    System.out.println("Placed order for "+user2.getUserid()+" is ");
                    order=orderDao.getOrderById(user2,od);
                    System.out.println(order.getOrderId()+" "+order.getTotalPayment()+" "+order.getStatus());
                    continue ADMIN;
                case 10:System.out.println("Enter the user id ");
                    int uid2=Integer.parseInt(sc.nextLine());
                    User user3=userDao.getUser(uid2);
                    for(Order order3:orderDao.viewAllOrder(user3))
                    {
                        System.out.println(order3.getOrderId()+" "+order3.getStatus()+" "+order3.getTotalPayment());
                    }
                    continue ADMIN;
                case 11:
                    category = createCategory();
                    categoryDao.addCategory(category);
                    System.out.println("New Category has been successfully added with id "+category.getCid());
                    continue ADMIN;
                case 12:
                    System.out.println("Enter the category id to be deleted");
                    int cid=Integer.parseInt(sc.nextLine());
                    categoryDao.deleteCategory(cid);
                    System.out.println("The category with id "+cid+" has been deleted successfully");
                    continue ADMIN;
                case 13:
                    System.out.println("Enter the Category id ");
                    int cid2=Integer.parseInt(sc.nextLine());
                    System.out.println("Enter the updated name ");
                    String ucn=sc.nextLine();
                    categoryDao.updateCategory(cid2,ucn);
                    System.out.println("Name changed successfully ");
                    continue ADMIN;
                case 14:
                    System.out.println("Enter the category id to get the details ");
                    int cid3=Integer.parseInt(sc.nextLine());
                    Category category1=categoryDao.getCategoryById(cid3);
                    System.out.println(category1.getCid()+" "+category1.getCname());
                    continue ADMIN;
                case 15:
                    System.out.println("The List of all Categories is ");
                    for(Category category2:categoryDao.getAllCategories())
                    {
                        System.out.println(category2.getCid()+" "+category2.getCname());
                    }
                    continue ADMIN;
                case 16:
                    System.out.println("Your credentials are ");
                    System.out.println("Your user id is "+ user.getUserid()
                            +" "+"Your name is "+user.getUserName()
                            +" "+"Your phone number is "+user.getPhoneNumber()
                            +" "+"Your email is "+user.getEmail());
                    continue ADMIN;
                case 17:
                    System.out.println("You are in update profile section ");
                    System.out.println("Enter your updated name");
                    String n = sc.nextLine();
                    userDao.updateUserName(user.getUserid(),n);
                    System.out.println("Your name has been updated successfully ");
                    continue ADMIN;
                case 18:
                    System.out.println("Enter the order id ");
                    int orderid = Integer.parseInt(sc.nextLine());
                    List<Product> productList = orderDao.showOrderItems(orderid);
                    System.out.println(productList);
                    continue ADMIN;
                case 19:
                    System.exit(0);
                default: break ADMIN;
            }
        }

        System.out.println("Thank you for shopping with Shoppers_Den");






//        UserDao userDao = new UserDaoImpl();
//        User user=userDao.getUser(10);
////        ProductDao productDao=new ProductImpl();
////        Product product=productDao.getProductById(62);
//
////        userDao.addUser(createUser());
//
////        User user = userDao.getUser(45);
//        OrderDao orderDao = new OrderDaoImpl();
////        Order order = orderDao.getOrderById(user,53);
////        orderDao.confirmOrder(user,order);
//
//        for(Order order:orderDao.viewAllOrder(user))
//        {
//            System.out.println(order.getOrderId()+" "+order.getUser().getUserid());
//        }
//        orderDao.placeOrder(user,createOrder());


//        CartDao cartDao = new CartDaoImpl();
//        cartDao.addProduct(user,product,5);
//        product=productDao.getProductById(92);
//        cartDao.addProduct(user,product,2);
//        cartDao.deleteProduct(user,69);
//        cartDao.updateQuantity(user,9,10);
//        cartDao.getAllProducts(user);


//        try
//        {
//            for(User user : userDao.getAllUsers())
//            {
//                System.out.println(user.getUserid() +" "+ user.getUserName()+" "+user.getUserRole()+" "+user.getCart().getCartId());
//            }
//        }
//        catch (SQLException e)
//        {
//            System.out.println(e.getMessage());
//        }
//        User user = userDao.getUser(45);
////
//        ProductDao productDao=new ProductImpl();
//        Product product=productDao.getProductById(77);
//        CartDao cartDao = new CartDaoImpl();
//        cartDao.addProduct(user,product,9);

//            CategoryDao categoryDao = new CategoryImpl();
////            Category category=categoryDao.getCategoryById(5);
////            System.out.println(category.getCid()+" "+category.getCname());
//            categoryDao.addCategory(createCategory());

//        ProductDao productDao = new ProductImpl();
//        try
//        {
//            for(Product product : productDao.getAllProducts())
//            {
//                System.out.println(product.getPid()+" "+product.getPname()+" "+product.getQty()+" "+product.getCategory());
//            }
//        }
//        catch (SQLException e)
//        {
//            System.out.println(e.getMessage());
//        }
//        for(int i=0;i<5;i++){
//        productDao.addProduct(createProduct());
//        productDao.deleteProduct(33);
//        productDao.updateProductName(69,"kitkat");



//        userDao.updateUserName(15, "pawry");
//        try{
//            userDao.deleteUser(80);
//        }
//        catch(SQLException e){
//            System.out.println(e.getMessage());
//        }
//        try{
//            User user = userDao.getUser(51);
//            System.out.println(user.getUserid() +" "+ user.getUserName()+" "+user.getUserRole());
//        }
//        catch(SQLException e){
//            System.out.println(e.getMessage());
//        }
//        for(int i=0;i<10;i++) {
//        userDao.addUser(createUser());}
//        try
//        {
//            for(User user : userDao.getAllUsers())
//            {
//                System.out.println(user.getUserid() +" "+ user.getUserName()+" "+user.getUserRole());
//            }
//        }
//        catch (SQLException e)
//        {
//            System.out.println(e.getMessage());
//        }
    }

    public static Product createProduct()
    {
        Product product=new Product();
        product.setDate(LocalDate.now());
        Category c=new Category();
        System.out.println("Enter the category id ");
        c.setCid(Integer.parseInt(sc.nextLine()));
        product.setCategory(c);
        System.out.println("Enter the product description ");
        product.setPdesc(sc.nextLine());
        System.out.println("Enter the price of the product ");
        product.setPrice(Integer.parseInt(sc.nextLine()));
        System.out.println("Enter the id of the product ");
        product.setPid(Integer.parseInt(sc.nextLine()));
        System.out.println("Enter the product name ");
        product.setPname(sc.nextLine());
        System.out.println("Enter the quantity of the product");
        product.setQty(Integer.parseInt(sc.nextLine()));
        return product;
    }

    public static Category createCategory()
    {
        Category category = new Category();
        System.out.println("Enter the Category Id");
        category.setCid(Integer.parseInt(sc.nextLine()));
        System.out.println("Enter the category name");
        category.setCname(sc.nextLine());
        return category;
    }

    public static User createUser()
    {
        User user = new User();
        System.out.println("Enter your phone number ");
        user.setPhoneNumber(Long.parseLong(sc.nextLine()));
        System.out.println("Enter your address ");
        user.setAddress(sc.nextLine());
        user.setUserid(new Random().nextInt(1000000000));
        System.out.println("Enter your username ");
        user.setUserName(sc.nextLine());
        System.out.println("Enter your security answer ");
        user.setAnswer(sc.nextLine());
        System.out.println("Enter your email ");
        user.setEmail(sc.nextLine());
        System.out.println("Enter your password ");
        user.setPassword(sc.nextLine());
        user.setEnabled(1);
        System.out.println("Enter your security question ");
        user.setSecurityQuestion(sc.nextLine());
        user.setUserRole(UserRole.ADMIN);
        Cart cart = new Cart();
        cart.setCartId(new Random().nextInt(100));
        cart.setUser(user);
        user.setCart(cart);
        return user;
    }

    public static Order createOrder() {
        Order o = new Order();
        o.setOrderId(new Random().nextInt(10000));
        System.out.println("Enter payment mode");
        String mode = sc.nextLine();
        if (mode.equalsIgnoreCase("Debit"))
        {
            o.setPaymentMode(PaymentMode.Debit);
        }
        else if(mode.equalsIgnoreCase("Credit"))
        {
            o.setPaymentMode(PaymentMode.Credit);
        }
        else
        {
            o.setPaymentMode(PaymentMode.UPI);
        }
        o.setStatus(0);
        return o;
    }

}
